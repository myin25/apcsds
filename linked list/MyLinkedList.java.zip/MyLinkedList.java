import java.util.Iterator;
import java.util.ListIterator;

public class MyLinkedList<E>
{
    private DoubleNode first;
    private DoubleNode last;
    private int size;

    public MyLinkedList()
    {
        first = null;
        last = null;
        size = 0;
    }

    public String toString()
    {
        DoubleNode node = first;
        if (node == null)
            return "[]";
        String s = "[";
        while (node.getNext() != null)
        {
            s += node.getValue() + ", ";
            node = node.getNext();
        }
        return s + node.getValue() + "]";
    }

    /** 
    * @precondition  0 <= index <= size / 2
    * @postcondition starting from first, returns the node
    *               with given index (where index 0
    *                 returns first)
    */               
    private DoubleNode getNodeFromFirst(int index)
    {
        if (index == 0)
        {
            return first;
        }
        
        DoubleNode node = first;
        for (int i = 0; i < index; i++)
        {
            node = node.getNext();
        }
        return node;
    }

    /** 
    * @precondition  size / 2 <= index < size
    * @postcondition starting from last, returns the node
    *               with given index (where index size-1
    *               returns last)
    */               
    private DoubleNode getNodeFromLast(int index)
    {
        if (index == size - 1)
        {
            return last;
        }
        
        DoubleNode node = first;
        for (int i = size - 1; i > index; i++)
        {
            node = node.getPrevious();
        }
        return node;
    }

    /** 
    * @precondition  0 <= index < size
    * @postcondition starting from first or last (whichever
    *               is closer), returns the node with given index
    */               
    private DoubleNode getNode(int index)
    {
        if (index >= size/2 && index < size)
        {
            return getNodeFromLast(index);
        }
        else
        {
            return getNodeFromFirst(index);
        }
    }

    /**
     * returns size of linked list
     * @return size of linked list
     */
    public int size()
    {
        return size;
    }

    /**
     * gets element at specified index
     * @param index is the location of element we are trying to get
     * @return element at specified index
     */
    public E get(int index)
    {
        return (E) getNode(index).getValue();
    }

    /** 
    * @postcondition replaces the element at position index with obj
                   returns the element formerly at the specified position
    */
    public E set(int index, E obj)
    {
        DoubleNode node = first;
        for (int i = 0; i < index; i++)
        {
            node = node.getNext();
        }

        E temp = (E) node.getValue();
        node.setValue(obj);
        return temp;
    }

    /**
    * @postcondition appends obj to end of list; returns true
    */
    public boolean add(E obj)
    {
        DoubleNode node = first;
        for (int i = 0; i < size; i++)
        {
            node = node.getNext();
        }
        node.setValue(obj);
        size += 1;
        return true;
    }

    /** 
    * @postcondition removes element from position index, moving elements
    *               at position index + 1 and higher to the left
    *               (subtracts 1 from their indices) and adjusts size
                   returns the element formerly at the specified position
    */
    public E remove(int index)
    {
        if (index == 0)
        {
            E temp = (E) first.getValue();
            first = first.getNext();
            size -= 1;
            return temp;
        }
        
        if (index >= size - 1)
        {
            E temp = (E) last.getValue();
            last = last.getPrevious();
            if (last != null)
            {
                last.setNext(null);
            }
            size -= 1;
            return temp;
        }
        
        DoubleNode node = getNode(index);
        
        E temp = (E) node.getValue();
        node = node.getPrevious();
        node.setNext(node.getNext().getNext());
        if (node.getNext() != null)
        {
            node.getNext().setPrevious(node);
        }
        node = node.getNext();
        
        if (node != null)
        {
            node.setPrevious(node.getPrevious().getPrevious());
        }
        
        size -= 1;
        return temp;
    }

    /** 
    * @precondition  0 <= index <= size
    * @postcondition inserts obj at position index,
    *                moving elements at position index and higher
    *                to the right (adds 1 to their indices) and adjusts size
    */
    public void add(int index, E obj)
    {
        if (index == 0)
        {
            addFirst(obj);
        }
        else if (index >= size)
        {
            addLast(obj);
        }
        else
        {
            DoubleNode currnode = first; //keeps track of where you are
            System.out.print(index - 1);
            for (int i = 0; i < index; i++) // get to node - 1
            {
                System.out.println("round " + i);
                currnode = currnode.getNext();
            }
            System.out.println("going to move everything starting at " + currnode);
            DoubleNode addnode = new DoubleNode(obj);
            addnode.setPrevious(currnode.getPrevious());
            addnode.setNext(currnode);
            currnode.getPrevious().setNext(addnode);
            currnode.setPrevious(addnode);
            size += 1;
        }
    }

    /**
     * adds new element at the beginning of the list
     */
    public void addFirst(E obj)
    {
        if (first == null)
        {
            first = new DoubleNode(obj);
            last = first;
        }
        else
        {
            DoubleNode node = new DoubleNode(obj);
            node.setNext(first);
            first.setPrevious(node);
            first = node;
        }
        size += 1;
    }
    
    /**
     * adds new element at the end of the list
     */
    public void addLast(E obj)
    {
        if (last == null)
        {
            first = new DoubleNode(obj);
            last = first;
        }
        else
        {
            DoubleNode node = new DoubleNode(obj);
            node.setPrevious(last);
            last.setNext(node);
            last = node;
        }
        size += 1;
    }

    /**
     * returns the first element of the list
     */
    public E getFirst()
    {
        return (E) first.getValue();
    }

    /**
     * returns the last element of the list
     */
    public E getLast()
    {
        return (E) last.getValue();
    }

    /**
     * removes first element of the list
     * @return the previous first element of the list
     */
    public E removeFirst()
    {
        if (first == null)
        {
            return null;
        }
        
        E temp = (E) first.getValue();
        
        if (first.getNext() == null)
        {
            first = null;
        }
        else
        {
            first = first.getNext();
        }
        
        size -= 1;
        return temp;
    }

    /**
     * removes the last element of the list
     * @return the previous last element of the list
     */
    public E removeLast()
    {
        if (last == null) //empty linked list
        {
            return null;
        }
        
        E temp = (E) last.getValue(); // store original last element
        
        // if the length of the linked list is 1 then make everything null
        if (last.getPrevious() == null)
        {
            last = null;
            first = null;
            return temp;
        }
        
        // else, change last to be the previous element
        last = last.getPrevious();
        last.setNext(null);
        
        size -= 1;
        
        return temp;
    }

    public Iterator<E> iterator()
    {
        return new MyLinkedListIterator();
    }

    private class MyLinkedListIterator implements Iterator<E>
    {
        private DoubleNode nextNode;

        public MyLinkedListIterator()
        {
            nextNode = first;
        }

        public boolean hasNext()
        {
            if (nextNode == null)
            {
                return false;
            }
            return true;
        }
        
        /**
         * adjusts nextNode to be next value in the linkedlist
         * @return null if at the end of the list, nextNode if not
         */
        public E next()
        {
            if (hasNext()) //alr initialized nextnode to be first node
            {
                E temp = (E) nextNode.getValue();
                nextNode = nextNode.getNext();
                return temp;
            }
            throw new IndexOutOfBoundsException("Reached the end of the list! No more elements.");
        }

        //@postcondition removes the last element that was returned by next
        public void remove()
        {
            if (nextNode.getPrevious() == first)
            {
                removeFirst();
            }
            else if (nextNode == null)
            {
                removeLast();
            }
            else
            {
            nextNode.getPrevious().getPrevious().setNext(nextNode);
            nextNode.setPrevious(nextNode.getPrevious().getPrevious());
            size --;
            }
        }
    }
}