
/**
 * Tests Jotto function from WordGame class
 *
 * @author Melody Yin
 * @version 1-27-22
 */
public class Tester
{
    public static void main(String[] args)
    {
        WordGame theGame = new WordGame();
        theGame.jotto();
    }
}
